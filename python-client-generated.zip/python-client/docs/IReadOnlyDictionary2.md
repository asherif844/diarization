# IReadOnlyDictionary2

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_none** | **list[str]** |  | [optional] 
**language** | **list[str]** |  | [optional] 
**acoustic** | **list[str]** |  | [optional] 
**pronunciation** | **list[str]** |  | [optional] 
**custom_voice** | **list[str]** |  | [optional] 
**audio_files** | **list[str]** |  | [optional] 
**keyword_audio_transcript** | **list[str]** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


