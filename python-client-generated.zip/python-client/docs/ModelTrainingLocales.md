# ModelTrainingLocales

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_none** | **list[str]** |  | [optional] 
**acoustic** | **list[str]** |  | [optional] 
**language** | **list[str]** |  | [optional] 
**acoustic_and_language** | **list[str]** |  | [optional] 
**custom_voice** | **list[str]** |  | [optional] 
**sentiment** | **list[str]** |  | [optional] 
**language_identification** | **list[str]** |  | [optional] 
**diarization** | **list[str]** |  | [optional] 
**keyword** | **list[str]** |  | [optional] 
**pronunciation_score** | **list[str]** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


